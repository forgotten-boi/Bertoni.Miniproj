﻿using System.Linq;
using System.Security.Cryptography.X509Certificates;

using System.Net;
using System.Net.Http.Headers;

namespace Bertoni.MiniProj.Models
{
    public class Album
    {
        public string UserId { get; set; }
        public string Title { get; set; }
        public string Id { get; set; }
    }
        


}
